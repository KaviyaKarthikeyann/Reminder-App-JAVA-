# NoteKeep
Note Keep is a easy and simple note app that you can use for quick note taking with a Note Reminder,Back up and Restore feature.
it uses Firebase Realtime Database for Back up and Restore

<a href="https://play.google.com/store/apps/details?id=com.notekeep.andrekelvin.notekeep" target="_blank">
<img src="https://play.google.com/intl/en_us/badges/images/generic/en-play-badge.png" alt="Get it on Google Play" height="90"/></a>


## Some Screen Shots
<img src="https://user-images.githubusercontent.com/39889856/71550005-4c169300-29c7-11ea-91f6-325d5edd139b.png" width=300 align=left>
<img src="https://user-images.githubusercontent.com/39889856/71550064-47061380-29c8-11ea-99c9-b2bb78ecc940.png" width=300 align=left>
<img src="https://user-images.githubusercontent.com/39889856/71550075-7288fe00-29c8-11ea-8444-94705667d102.png" width=300 align=left>
<img src="https://user-images.githubusercontent.com/39889856/71550077-73219480-29c8-11ea-91d2-153e84bdd35e.png" width=300 align=left>
<img src="https://user-images.githubusercontent.com/39889856/71550103-dd3a3980-29c8-11ea-9cb2-3055a4d7088e.png" width=300 align=left>
<img src="https://user-images.githubusercontent.com/39889856/71550104-dd3a3980-29c8-11ea-82f8-5896e9187b98.png" width=300 align=left>
<img src="https://user-images.githubusercontent.com/39889856/71550160-23dc6380-29ca-11ea-9906-91aabfa14e6e.png" width=300 align=left>
